declare enum DisplayName {
    Accordion = "Accordion",
    AccordionItem = "AccordionItem",
    AccordionItemButton = "AccordionItemButton",
    AccordionItemHeading = "AccordionItemHeading",
    AccordionItemPanel = "AccordionItemPanel"
}
export default DisplayName;
