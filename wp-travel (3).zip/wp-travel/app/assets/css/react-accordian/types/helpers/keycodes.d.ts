declare const keycodes: {
    END: string;
    ENTER: string;
    HOME: string;
    SPACE: string;
    SPACE_DEPRECATED: string;
    UP: string;
    DOWN: string;
    LEFT: string;
    RIGHT: string;
};
export default keycodes;
