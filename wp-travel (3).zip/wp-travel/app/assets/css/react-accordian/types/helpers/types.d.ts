import * as React from 'react';
export declare type DivAttributes = React.HTMLAttributes<HTMLDivElement>;
